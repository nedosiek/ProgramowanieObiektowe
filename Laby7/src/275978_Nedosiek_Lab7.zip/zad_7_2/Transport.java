package zad_7_2;

public interface Transport {
    double calculateCost(double distance);
}
